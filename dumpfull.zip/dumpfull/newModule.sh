#!/bin/bash

file="d.txt"
access_key_pattern="AKIA[A-Z0-9]{16}"
secret_key_pattern_v1="[0-9a-zA-Z/+]{40}"
secret_key_pattern_v2="[0-9a-zA-Z/+]{40,47}"
email_pattern="\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"
smtp_region_pattern="email-smtp\.(us|eu|ap|ca|cn|sa)-(central|(north|south)?(west|east)?)-[0-9]{1}\.amazonaws.com"

process_keys() {
    local secret_pattern=$1
    local output_file=$2

    grep -aEo "$access_key_pattern" "$file" | sort -u | while read -r key; do
        grep -aC25 "$key" "$file" | grep -aEo "$secret_pattern" |sort -u |  head -n10 | while read -r secret; do
            if [[ "$secret_pattern" == "$secret_key_pattern_v1" ]]; then
                echo "$key:$secret" >> "$output_file"
            else
                grep -aC50 "$key" "$file" | grep -aEo "$email_pattern" | sort -u | head -n10 | while read -r email; do
                    grep -aC50 "$key" "$file" | grep -aEo "$smtp_region_pattern" |sort -u |  head -n10 | while read -r region; do
                        echo "$key:$secret:$region:$email" >> "$output_file"
                    done
                done
            fi
        done
    done
}

process_keys "$secret_key_pattern_v1" "aws.txt"
process_keys "$secret_key_pattern_v2" "smtp.txt"
