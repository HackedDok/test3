import ipaddress

def read_ip_file(file_name):
    with open(file_name, 'r') as file:
        lines = file.readlines()
        ip1 = lines[0].strip().strip("'")
        ip2 = lines[1].strip().strip("'")
        return ip1, ip2

def calculate_ip_range(ip1, ip2):
    start = int(ipaddress.IPv4Address(ip1.split('/')[0]))
    end = int(ipaddress.IPv4Address(ip2.split('/')[0]))
    # Nous allons utiliser un ensemble pour éviter les doublons
    return sorted(set(str(ipaddress.IPv4Address(ip)) for ip in range(start, end + 1)))

def write_ips_to_file(ip_range, directory="."):
    file_name = f"{directory}/{len(ip_range)}_ip.txt"
    with open(file_name, 'w') as file:
        for ip in ip_range:
            file.write(f"{ip}\n")
    return file_name

# Nom du fichier d'entrée dans le même répertoire
file_name = 'input_ips.txt'  # Assurez-vous que ce fichier existe dans le répertoire
ip1, ip2 = read_ip_file(file_name)
ip_range = calculate_ip_range(ip1, ip2)
output_file = write_ips_to_file(ip_range)
print(f"Le fichier '{output_file}' a été créé avec succès.")
