from random import randint
from socket import inet_ntoa
from struct import pack

from http.client import HTTPConnection, HTTPException, HTTPSConnection 
from colorama import Fore, init; init();
import os, threading
lock = threading.Lock()

live, dead = 0, 0

def CheckIP(ip):
    global live, dead
    ports = [80]
    for port in ports:
        if port == 443:
            from ssl import _create_unverified_context as cuc
            req = HTTPSConnection(ip, context=cuc(), timeout=5)
        else:
            req = HTTPConnection(ip, port=port, timeout=2)
        try:
            req.request('GET', "/", headers={'User-Agent': 'Mozilla/5.0'})
            r = req.getresponse()
            r.read()

            if (100 <= r.status < 300):
                lock.acquire()
                live += 1
                print(Fore.GREEN + f"Live IP ---> " + ip+":80" +Fore.RESET)
                open("hits_ips.txt", 'a+').write(ip+"\n")
                lock.release()            
        except:
            lock.acquire()
            dead+=1
            # print(Fore.RED +   f"Dead IP ---> " + ip+":80" +Fore.RESET)
            lock.release()
    
    os.system(f"title Live: {live} ^| Dead: {dead}")


def global_ip_generator(count=10):
    ips = []
    while count:
        intip = randint(0x1000000, 0xE0000000)
        if (0xa000000 <= intip <= 0xaffffff
                or 0x64400000 <= intip <= 0x647fffff
                or 0x7f000000 <= intip <= 0x7fffffff
                or 0xa9fe0000 <= intip <= 0xa9feffff
                or 0xac100000 <= intip <= 0xac1fffff
                or 0xc0000000 <= intip <= 0xc0000007
                or 0xc00000aa <= intip <= 0xc00000ab
                or 0xc0000200 <= intip <= 0xc00002ff
                or 0xc0a80000 <= intip <= 0xc0a8ffff
                or 0xc6120000 <= intip <= 0xc613ffff
                or 0xc6336400 <= intip <= 0xc63364ff
                or 0xcb007100 <= intip <= 0xcb0071ff
                or 0xf0000000 <= intip <= 0xffffffff):
            continue
        count -= 1
        ips.append(inet_ntoa(pack('>I', intip)).split())
    return ips
while True:
    all_threads = []
    for _ in range(10):
        ips = global_ip_generator(40)
        for ip in ips:
            all_threads.append(threading.Thread(target=CheckIP, args=(ip[0], )))

    for T in all_threads:
        T.start()

    for T in all_threads:
        T.join()